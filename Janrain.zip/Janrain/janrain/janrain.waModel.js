﻿
guidedModel =// @startlock
{
};// @endlock
