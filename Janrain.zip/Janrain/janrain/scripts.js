﻿
//currentSession().promoteWith("Users");
//ds.User.all().forEach(function (foo) {
//	foo.remove();
//});
//ds.User.all();