﻿addHttpRequestHandler(
      '/janrainresponse.html',               
      'required.js',  
      'janrainresponse'         
);